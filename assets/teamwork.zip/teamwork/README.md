# Teamwork Plugin

Collaborate with ChatGPT, Gemini, and Grok alongside Claude — ask, compare, synthesize, or
validate across AI assistants in a single conversation.

## What it does

Three collaboration types:

1. **Synthesize** — Claude and one or more bots all answer the same question; Claude combines
   the best material from every response into one high-quality answer.
2. **Verbatim** — Claude prompts a bot and shows you its response word for word.
3. **Validate** — Claude shares its own work with another bot to get a second opinion.

## Setup

On first use, the plugin walks you through connecting your chosen AI assistants. You'll need an
API key for each one — the plugin guides you through getting each key step by step.

Supported assistants: ChatGPT (OpenAI), Gemini (Google), Grok (xAI).

## Usage

Just chat naturally. Examples:

- *"Ask ChatGPT and yourself the same question, then give me the best combined answer"*
- *"Show me exactly what Grok says about this"*
- *"Have Gemini check this email I wrote"*

You can also ask to change your model preference (fast vs. powerful), add a new bot, or
disconnect one at any time.

## Components

| Component | Purpose |
|-----------|---------|
| `skills/teamwork/SKILL.md` | Core plugin logic — onboarding, collaboration, API calls |
| `skills/teamwork/scripts/storage.py` | Persistent storage helpers |
| `skills/teamwork/scripts/call_api.py` | API call functions for all three providers |
| `skills/teamwork/scripts/check_models.py` | Model version tracking and update logic |

## Notes

- API keys and preferences are stored in the plugin's persistent cache and survive new chat sessions.
- Reinstalling the plugin resets stored settings — you'll need to re-enter your API keys.
- Works identically on macOS and Windows (Cowork runs in a Linux VM on both).
