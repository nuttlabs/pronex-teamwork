"""
storage.py — Teamwork Plugin
Locates the plugin's .mcpb-cache persistent storage directory and provides
helpers for reading/writing config.

Usage:
    python3 storage.py

Prints the resolved config directory path and a summary of current state.
Importable by other scripts as a module.
"""

import os
import json
import glob
from datetime import date


# ---------------------------------------------------------------------------
# Storage detection
# ---------------------------------------------------------------------------

def find_persistent_storage() -> str:
    """
    Locate the plugin's .mcpb-cache directory.

    Primary scan uses /proc/mounts (fast, reliable). Glob scan is the
    backup in case /proc/mounts is unavailable or uses an unexpected
    filesystem type.

    If multiple .mcpb-cache paths exist (e.g. two plugin versions installed
    side by side), prefer the one whose api_keys.json has the most entries
    so the most complete configuration is always used.

    Raises RuntimeError if no .mcpb-cache is found, which indicates the
    plugin is not properly installed.
    """
    # Primary: /proc/mounts scan.
    # Collect ALL matching candidates first — mount order is non-deterministic.
    candidates: list[str] = []
    try:
        with open("/proc/mounts") as f:
            for line in f:
                parts = line.split()
                if len(parts) < 4:
                    continue
                mountpoint = parts[1]
                fstype     = parts[2]
                options    = parts[3]
                if (
                    fstype == "fuse.bindfs"
                    and "rw" in options.split(",")
                    and "/.local-plugins/" in mountpoint
                    and ".mcpb-cache" in mountpoint
                ):
                    candidates.append(os.path.join(mountpoint, "teamwork"))
    except Exception:
        pass

    if candidates:
        existing = [c for c in candidates
                    if os.path.exists(os.path.join(c, "api_keys.json"))]
        if existing:
            def _key_count(p: str) -> int:
                try:
                    with open(os.path.join(p, "api_keys.json")) as fh:
                        return len(json.load(fh))
                except Exception:
                    return 0
            cache_dir: str = max(existing, key=_key_count)
        else:
            cache_dir = sorted(candidates)[0]
        os.makedirs(cache_dir, exist_ok=True)
        return cache_dir

    # Backup: recursive glob — handles non-fuse.bindfs mounts or unreadable /proc/mounts.
    matches = [
        p for p in glob.glob(
            "/sessions/*/mnt/.local-plugins/**/.mcpb-cache",
            recursive=True,
        )
        if os.path.isdir(p)
    ]
    if matches:
        existing = [m for m in matches
                    if os.path.exists(os.path.join(m, "teamwork", "api_keys.json"))]
        if existing:
            def _key_count(p: str) -> int:
                try:
                    with open(os.path.join(p, "teamwork", "api_keys.json")) as fh:
                        return len(json.load(fh))
                except Exception:
                    return 0
            best = max(existing, key=_key_count)
        else:
            best = sorted(matches)[0]
        cache_dir = os.path.join(best, "teamwork")
        os.makedirs(cache_dir, exist_ok=True)
        return cache_dir

    raise RuntimeError(
        "Teamwork plugin cache not found. Please reinstall the Teamwork plugin."
    )


# ---------------------------------------------------------------------------
# JSON helpers
# ---------------------------------------------------------------------------

def save_json(path: str, data: dict) -> None:
    """Atomically write JSON using rename — safe even on delete-deny mounts."""
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, path)


def load_json(path: str, default=None) -> dict:
    """Load a JSON file, returning `default` on any error."""
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default if default is not None else {}


# ---------------------------------------------------------------------------
# Convenience: resolve all config file paths at once
# ---------------------------------------------------------------------------

def get_config_paths(config_dir: str) -> dict:
    return {
        "keys":    os.path.join(config_dir, "api_keys.json"),
        "models":  os.path.join(config_dir, "models.json"),
        "prefs":   os.path.join(config_dir, "preferences.json"),
        "session": os.path.join(config_dir, "session.json"),
    }


# ---------------------------------------------------------------------------
# Session marker
# ---------------------------------------------------------------------------

def is_first_session_invocation(session_path: str) -> bool:
    """True if this is the first time the plugin has been invoked today."""
    session = load_json(session_path)
    return session.get("date") != str(date.today())


def mark_session(session_path: str) -> None:
    """Record today's date so we don't re-run the model refresh this session."""
    save_json(session_path, {"date": str(date.today())})


# ---------------------------------------------------------------------------
# Standalone: print status when run directly
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    config_dir = find_persistent_storage()
    paths      = get_config_paths(config_dir)
    fresh      = is_first_session_invocation(paths["session"])

    api_keys   = load_json(paths["keys"])
    prefs      = load_json(paths["prefs"])

    print(f"Config dir   : {config_dir}")
    print(f"First today  : {fresh}")
    print(f"Keys saved   : {list(api_keys.keys())}")
    print(f"Onboarded    : {prefs.get('onboarding_complete', False)}")
    print(f"Model pref   : {prefs.get('default_model_type', 'not set')}")
