"""
call_api.py — Teamwork Plugin
Calls OpenAI (ChatGPT), Google (Gemini), or xAI (Grok) and returns the text response.

Dependencies (install once per session):
    pip install openai google-genai --break-system-packages -q

Usage:
    python3 call_api.py <provider> <api_key> <model_id> "<prompt>"

    provider  : openai | gemini | grok
    api_key   : the saved API key for that provider
    model_id  : exact model string, e.g. "gpt-4.1-mini"
    prompt    : the text to send

Exits with code 0 on success (prints response to stdout).
Exits with code 1 on error (prints a user-safe error message to stderr).
"""

import sys


# ---------------------------------------------------------------------------
# Provider call functions
# ---------------------------------------------------------------------------

def call_openai(api_key: str, model_id: str, prompt: str) -> str:
    """Call OpenAI's chat completions endpoint."""
    from openai import OpenAI, AuthenticationError, RateLimitError

    try:
        client   = OpenAI(api_key=api_key)
        response = client.chat.completions.create(
            model=model_id,
            messages=[{"role": "user", "content": prompt}],
            timeout=60,
        )
        return response.choices[0].message.content or ""
    except AuthenticationError:
        raise ValueError("auth_error")
    except RateLimitError:
        raise ValueError("rate_limit")
    except Exception as e:
        raise ValueError(f"connection_error: {type(e).__name__}")


def call_gemini(api_key: str, model_id: str, prompt: str) -> str:
    """Call Google Gemini via the google-genai SDK (unified SDK, GA since May 2025)."""
    from google import genai as google_genai
    from google.api_core.exceptions import PermissionDenied, ResourceExhausted

    try:
        client   = google_genai.Client(
            api_key=api_key,
            http_options={"timeout": 60},
        )
        response = client.models.generate_content(
            model=model_id,
            contents=prompt,
        )
    except PermissionDenied:
        raise ValueError("auth_error")
    except ResourceExhausted:
        raise ValueError("rate_limit")
    except Exception as e:
        raise ValueError(f"connection_error: {type(e).__name__}")

    # response.text is None when finish_reason is SAFETY or RECITATION.
    # Separate this from network/auth errors so it isn't retried.
    try:
        return response.text or ""
    except (ValueError, AttributeError):
        raise ValueError("content_blocked")


def call_grok(api_key: str, model_id: str, prompt: str) -> str:
    """
    Call xAI Grok using the OpenAI-compatible API.
    xAI's endpoint mirrors the OpenAI interface — only the base_url differs.
    """
    from openai import OpenAI, AuthenticationError, RateLimitError

    try:
        client   = OpenAI(api_key=api_key, base_url="https://api.x.ai/v1")
        response = client.chat.completions.create(
            model=model_id,
            messages=[{"role": "user", "content": prompt}],
            timeout=60,
        )
        return response.choices[0].message.content or ""
    except AuthenticationError:
        raise ValueError("auth_error")
    except RateLimitError:
        raise ValueError("rate_limit")
    except Exception as e:
        raise ValueError(f"connection_error: {type(e).__name__}")


# ---------------------------------------------------------------------------
# Web-search-enabled call functions
# ---------------------------------------------------------------------------

def call_openai_with_search(api_key: str, model_id: str, prompt: str) -> str:
    """Call OpenAI's Responses API with the web_search_preview tool enabled."""
    from openai import OpenAI, AuthenticationError, RateLimitError

    try:
        client   = OpenAI(api_key=api_key)
        response = client.responses.create(
            model=model_id,
            tools=[{"type": "web_search_preview"}],
            input=prompt,
            timeout=60,
        )
        return response.output_text or ""
    except AuthenticationError:
        raise ValueError("auth_error")
    except RateLimitError:
        raise ValueError("rate_limit")
    except Exception as e:
        raise ValueError(f"connection_error: {type(e).__name__}")


def call_gemini_with_search(api_key: str, model_id: str, prompt: str) -> str:
    """Call Google Gemini with Google Search grounding enabled (google-genai SDK)."""
    from google import genai as google_genai
    from google.genai import types as genai_types
    from google.api_core.exceptions import PermissionDenied, ResourceExhausted

    try:
        client   = google_genai.Client(
            api_key=api_key,
            http_options={"timeout": 60},
        )
        grounding_tool = genai_types.Tool(google_search=genai_types.GoogleSearch())
        config         = genai_types.GenerateContentConfig(tools=[grounding_tool])
        response = client.models.generate_content(
            model=model_id,
            contents=prompt,
            config=config,
        )
    except PermissionDenied:
        raise ValueError("auth_error")
    except ResourceExhausted:
        raise ValueError("rate_limit")
    except Exception as e:
        raise ValueError(f"connection_error: {type(e).__name__}")

    # response.text is None when finish_reason is SAFETY or RECITATION.
    # Separate this from network/auth errors so it isn't retried.
    try:
        return response.text or ""
    except (ValueError, AttributeError):
        raise ValueError("content_blocked")


def call_grok_with_search(api_key: str, model_id: str, prompt: str) -> str:
    """
    Call xAI Grok with live web search enabled.
    Uses the xAI Responses API (OpenAI-compatible) with the web_search tool.
    NOTE: The legacy search_parameters/extra_body Chat Completions approach was
    retired by xAI on January 12, 2026 and now returns HTTP 410 Gone.
    """
    from openai import OpenAI, AuthenticationError, RateLimitError

    try:
        client   = OpenAI(api_key=api_key, base_url="https://api.x.ai/v1")
        response = client.responses.create(
            model=model_id,
            input=[{"role": "user", "content": prompt}],
            tools=[{"type": "web_search"}],
            timeout=60,
        )
        return response.output_text or ""
    except AuthenticationError:
        raise ValueError("auth_error")
    except RateLimitError:
        raise ValueError("rate_limit")
    except Exception as e:
        raise ValueError(f"connection_error: {type(e).__name__}")


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------

PROVIDERS = {
    "openai": call_openai,
    "gemini": call_gemini,
    "grok":   call_grok,
}

WEB_SEARCH_PROVIDERS = {
    "openai": call_openai_with_search,
    "gemini": call_gemini_with_search,
    "grok":   call_grok_with_search,
}


def call_bot(provider: str, api_key: str, model_id: str, prompt: str) -> str:
    """
    Unified entry point. Returns the response text.
    Raises ValueError with a short error code on failure.
    """
    fn = PROVIDERS.get(provider.lower())
    if fn is None:
        raise ValueError(f"unknown_provider: {provider}")
    return fn(api_key, model_id, prompt)


def call_bot_with_search(provider: str, api_key: str, model_id: str, prompt: str) -> str:
    """
    Unified entry point for web-search-enabled calls. Returns the response text.
    Raises ValueError with a short error code on failure.
    """
    fn = WEB_SEARCH_PROVIDERS.get(provider.lower())
    if fn is None:
        raise ValueError(f"unknown_provider: {provider}")
    return fn(api_key, model_id, prompt)


# ---------------------------------------------------------------------------
# User-friendly error messages (for Claude to present to the user)
# ---------------------------------------------------------------------------

USER_ERRORS = {
    "auth_error": (
        "It looks like the key for {bot} isn't working right now — "
        "it may have expired or been entered with a typo. "
        "Want me to help you get a new one?"
    ),
    "rate_limit": (
        "{bot} is asking us to slow down a bit — the usage limit has been reached. "
        "You could wait a minute and try again, or check whether your plan needs an upgrade."
    ),
    "connection_error": (
        "I wasn't able to reach {bot} just now. Let me try one more time."
    ),
    "content_blocked": (
        "{bot} wasn't able to respond to that particular request — "
        "it flagged the content. You could try rephrasing, "
        "or I can continue with the other AIs."
    ),
}

BOT_NAMES = {
    "openai": "ChatGPT",
    "gemini": "Gemini",
    "grok":   "Grok",
}


def friendly_error(provider: str, error_code: str) -> str:
    bot  = BOT_NAMES.get(provider, provider.title())
    tmpl = USER_ERRORS.get(
        error_code.split(":")[0],
        "Something went wrong reaching {bot}. Let me try once more."
    )
    return tmpl.format(bot=bot)


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    if len(sys.argv) < 5:
        print("Usage: call_api.py <provider> <api_key> <model_id> <prompt>", file=sys.stderr)
        sys.exit(1)

    _provider  = sys.argv[1]
    _api_key   = sys.argv[2]
    _model_id  = sys.argv[3]
    _prompt    = sys.argv[4]

    try:
        result = call_bot(_provider, _api_key, _model_id, _prompt)
        print(result)
        sys.exit(0)
    except ValueError as e:
        msg = friendly_error(_provider, str(e))
        print(msg, file=sys.stderr)
        sys.exit(1)
