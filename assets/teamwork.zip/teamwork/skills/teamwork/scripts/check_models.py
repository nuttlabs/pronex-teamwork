"""
check_models.py — Teamwork Plugin
Fetches the latest powerful and fast model IDs from each provider's documentation
and compares them to what's stored in models.json.

This script is designed to be called by Claude at the start of the first session
invocation each day. It uses web searches (performed by Claude) to get current model
information — this script handles the storage and comparison logic.

Usage (called by Claude after performing web searches):
    python3 check_models.py <config_dir> <provider> <powerful_id> <fast_id> [web_search_notes]

    config_dir        : path to the persistent config directory (from storage.py)
    provider          : openai | gemini | grok
    powerful_id       : current powerful model ID found via web search
    fast_id           : current fast model ID found via web search
    web_search_notes  : (optional) change summary if web search syntax differs from Part 5
                        defaults; omit or pass "" if defaults still apply

Prints "UPDATED" if models.json was changed, "UNCHANGED" if nothing changed.

Claude should call this script once per configured provider after searching the web
for that provider's current model IDs.
"""

import sys
import os
import json
from datetime import date

# Reuse helpers from storage.py if available
_dir = os.path.dirname(os.path.abspath(__file__))
if os.path.exists(os.path.join(_dir, "storage.py")):
    sys.path.insert(0, _dir)
    from storage import save_json, load_json
else:
    def save_json(path, data):
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        os.replace(tmp, path)

    def load_json(path, default=None):
        try:
            with open(path, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return default if default is not None else {}


# ---------------------------------------------------------------------------
# Known fallback model IDs (used only if web search produces no result)
# These will be overridden whenever Claude successfully searches for updates.
# ---------------------------------------------------------------------------

FALLBACK_MODELS = {
    "openai": {
        "powerful":         "gpt-5.4",
        "fast":             "gpt-5-mini",
        "web_search_notes": "",
    },
    "gemini": {
        "powerful":         "gemini-3.1-pro-preview",
        "fast":             "gemini-3.1-flash-lite-preview",
        "web_search_notes": "",
    },
    "grok": {
        "powerful":         "grok-4",
        "fast":             "grok-4.1-fast",
        "web_search_notes": "",
    },
}


def update_models(
    config_dir: str,
    provider: str,
    powerful_id: str,
    fast_id: str,
    web_search_notes: str = "",
) -> bool:
    """
    Compare new model IDs and web search notes to stored values. Save if changed.
    Returns True if an update was made.
    Refuses to overwrite stored IDs with empty strings — returns False if either ID is empty.
    """
    if not powerful_id or not fast_id:
        return False  # never overwrite valid stored IDs with empty strings

    models_path = os.path.join(config_dir, "models.json")
    models = load_json(models_path)

    current = models.get(provider, {})
    changed = (
        current.get("powerful") != powerful_id
        or current.get("fast") != fast_id
        or current.get("web_search_notes", "") != web_search_notes
    )

    if changed:
        # Preserve all existing fields; only overwrite what changed.
        updated = dict(current)
        updated["powerful"]         = powerful_id
        updated["fast"]             = fast_id
        updated["web_search_notes"] = web_search_notes
        models[provider]       = updated
        models["last_checked"] = str(date.today())
        save_json(models_path, models)

    return changed


def initialize_missing_models(config_dir: str, configured_providers: list) -> None:
    """
    Seed models.json with fallback values for any provider that has no entry yet.
    Called during onboarding if Claude's web search didn't find a specific model ID.
    """
    models_path = os.path.join(config_dir, "models.json")
    models = load_json(models_path)
    changed = False

    for provider in configured_providers:
        if provider not in models and provider in FALLBACK_MODELS:
            models[provider] = FALLBACK_MODELS[provider].copy()
            changed = True

    if changed:
        models.setdefault("last_checked", str(date.today()))
        save_json(models_path, models)


def get_model_id(config_dir: str, provider: str, model_type: str) -> str:
    """
    Retrieve the stored model ID for a given provider and type ("powerful" or "fast").
    Falls back to FALLBACK_MODELS if not stored.
    """
    models_path = os.path.join(config_dir, "models.json")
    models = load_json(models_path)
    provider_models = models.get(provider, FALLBACK_MODELS.get(provider, {}))
    return provider_models.get(model_type, "")


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    if len(sys.argv) < 5:
        print(
            "Usage: check_models.py <config_dir> <provider> <powerful_id> <fast_id>"
            " [web_search_notes]",
            file=sys.stderr,
        )
        sys.exit(1)

    _config_dir       = sys.argv[1]
    _provider         = sys.argv[2]
    _powerful_id      = sys.argv[3]
    _fast_id          = sys.argv[4]
    _web_search_notes = sys.argv[5] if len(sys.argv) > 5 else ""

    was_updated = update_models(
        _config_dir, _provider, _powerful_id, _fast_id, _web_search_notes
    )
    print("UPDATED" if was_updated else "UNCHANGED")
    sys.exit(0)
